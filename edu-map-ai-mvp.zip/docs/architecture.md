# Arquitectura

## Frontend

HTML, CSS y JavaScript.

## Backend

Node.js + Express.

## Endpoint

`POST /api/generate`

Entrada:
- level
- subject
- topic
- duration
- objective
- methodology
- characteristics

Salida:
- objetivo
- anticipacion
- construccion
- consolidacion
- recursos
- evaluacion
- criterios
- rubrica
- dua

## IA

El archivo `backend/services/ai.js` contiene el prompt maestro y el adaptador del proveedor.

La clave se mantiene únicamente en variables de entorno del servidor.
