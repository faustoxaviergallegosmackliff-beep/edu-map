document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("plannerForm");
  const result = document.getElementById("result");

  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    const button = form.querySelector("button[type='submit']");
    button.disabled = true;
    button.textContent = "Generando...";

    result.classList.remove("hidden");
    result.innerHTML = `
      <div class="result-card">
        <span class="eyebrow">EDU-MAP · IA</span>
        <h2>Generando experiencia educativa...</h2>
        <div class="notice">
          Analizando objetivo · Diseñando actividades · Preparando evaluación · Aplicando DUA
        </div>
      </div>`;

    const payload = {
      level: document.getElementById("level").value,
      subject: document.getElementById("subject").value,
      topic: document.getElementById("topic").selectedOptions[0].text,
      duration: document.getElementById("duration").value,
      objective: document.getElementById("objective").value.trim(),
      methodology: ["ACC", "DUA"],
      characteristics: [
        "Diferentes ritmos de aprendizaje",
        "Apoyo visual",
        "Trabajo colaborativo"
      ]
    };

    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Error de generación.");

      renderPlan(data, payload);
    } catch (error) {
      result.innerHTML = `
        <div class="result-card">
          <h2>No se pudo generar la planificación</h2>
          <p>${escapeHtml(error.message)}</p>
          <div class="notice">Si estás probando localmente, verifica que el servidor esté ejecutándose con <code>npm start</code>.</div>
        </div>`;
    } finally {
      button.disabled = false;
      button.textContent = "Generar planificación →";
    }
  });

  function renderPlan(data, payload) {
    const rubric = Array.isArray(data.rubrica)
      ? `<div class="result-grid">${data.rubrica.map(r => `
          <div class="result-tile">
            <strong>${escapeHtml(r.criterio || "")}</strong>
            <p><b>Inicial:</b> ${escapeHtml(r.inicial || "")}</p>
            <p><b>En proceso:</b> ${escapeHtml(r.proceso || "")}</p>
            <p><b>Logrado:</b> ${escapeHtml(r.logrado || "")}</p>
          </div>`).join("")}</div>`
      : "";

    result.innerHTML = `
      <div class="result-card">
        <span class="eyebrow">RESULTADO · ${escapeHtml(payload.level)}</span>
        <h2>${escapeHtml(payload.topic)}</h2>
        <p><strong>${escapeHtml(payload.subject)}</strong> · ${escapeHtml(payload.duration)}</p>

        ${section("Objetivo de aprendizaje", data.objetivo)}
        ${section("🟢 Anticipación", data.anticipacion)}
        ${section("🔵 Construcción", data.construccion)}
        ${section("🟣 Consolidación", data.consolidacion)}
        ${listSection("📚 Recursos", data.recursos)}
        ${listSection("📊 Evaluación", data.evaluacion)}
        ${listSection("🎯 Criterios", data.criterios)}
        ${sectionHtml("📋 Rúbrica", rubric)}
        ${listSection("🧩 DUA", data.dua)}

        <div class="notice">
          <strong>Estado:</strong> ${data.modo === "demo" ? "modo demostración local" : "generado mediante IA"}.
          El docente debe revisar y personalizar el contenido antes de utilizarlo.
        </div>

        <button class="btn edit-btn" onclick="window.print()">Guardar / imprimir propuesta</button>
      </div>`;
    result.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function section(title, text) {
    return sectionHtml(title, `<p>${escapeHtml(text || "")}</p>`);
  }

  function listSection(title, items) {
    const safeItems = Array.isArray(items) ? items : [];
    return sectionHtml(title, `<ul>${safeItems.map(x => `<li>${escapeHtml(String(x))}</li>`).join("")}</ul>`);
  }

  function sectionHtml(title, html) {
    return `<div class="result-section"><h3>${title}</h3>${html}</div>`;
  }

  function escapeHtml(value) {
    return String(value)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }
});
