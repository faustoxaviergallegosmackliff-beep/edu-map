# EDU-MAP · MVP + Backend IA

EDU-MAP es un prototipo de asistente para planificación docente.

## Caso de uso inicial

- Nivel: 8.º EGB
- Asignatura: Matemáticas
- Tema de demostración: Operaciones con números enteros
- Metodología: ACC
- Enfoque: DUA

## Arquitectura

```text
Navegador
   ↓
Frontend HTML/CSS/JS
   ↓
POST /api/generate
   ↓
Backend Express
   ↓
Servicio de IA
   ↓
JSON estructurado
   ↓
Interfaz EDU-MAP
```

## Seguridad

Las claves de API deben permanecer en variables de entorno.

Nunca subir `.env` al repositorio.

El archivo `.env.example` solo muestra qué variables necesita el servidor.

## Ejecución local

Requisitos: Node.js.

```bash
npm install
npm start
```

Abrir:

```text
http://localhost:3000
```

## Modo demo

Si `AI_API_URL` y `AI_API_KEY` no están configuradas, EDU-MAP usa una respuesta local de demostración. Esto permite probar la interfaz sin una clave.

## Modo IA

Configurar las variables del entorno en el servidor:

```text
AI_API_URL=
AI_API_KEY=
AI_MODEL=
```

El adaptador espera una API HTTP compatible con el patrón de chat:

```text
choices[0].message.content
```

La respuesta del modelo debe ser JSON válido.

## Próximas fases

1. Probar MVP.
2. Conectar proveedor de IA elegido.
3. Validar JSON y errores.
4. Mejorar experiencia visual.
5. Crear repositorio GitHub.
6. Configurar despliegue seguro.
7. Añadir más niveles y asignaturas.
