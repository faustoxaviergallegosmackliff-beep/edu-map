const SYSTEM_PROMPT = `
Eres EDU-MAP, un asistente especializado en diseño de experiencias de aprendizaje.

Tu función es ayudar al docente a transformar una necesidad educativa en una
propuesta estructurada, clara, contextualizada y editable.

No reemplazas el criterio profesional del docente. Todo contenido generado
debe ser revisado y adaptado por el docente antes de utilizarse.

REGLAS:
- Usa lenguaje pedagógico claro.
- Mantén coherencia entre objetivo, actividades y evaluación.
- Las actividades deben ser apropiadas para la edad.
- Utiliza ACC cuando se solicite: Anticipación, Construcción y Consolidación.
- Si se solicita DUA, incluye Representación, Acción y expresión, y Participación.
- No inventes códigos curriculares si no fueron proporcionados.
- Propón recursos realistas.
- Evita actividades genéricas.
- Devuelve exclusivamente JSON válido.

FORMATO:
{
  "objetivo": "",
  "anticipacion": "",
  "construccion": "",
  "consolidacion": "",
  "recursos": [],
  "evaluacion": [],
  "criterios": [],
  "rubrica": [],
  "dua": []
}
`;

function buildPrompt(input) {
  return `${SYSTEM_PROMPT}

DATOS DEL DOCENTE:
Nivel: ${input.level}
Asignatura: ${input.subject}
Tema: ${input.topic}
Duración: ${input.duration || "No especificada"}
Objetivo: ${input.objective || "Proponer uno coherente con el tema"}
Metodología: ${(input.methodology || ["ACC", "DUA"]).join(", ")}
Características del grupo: ${(input.characteristics || []).join(", ")}
`;
}

async function generateEducationalPlan(input) {
  /*
   * MODO DEMO:
   * Si no existe una API configurada, devolvemos una respuesta local.
   * Esto permite probar el proyecto sin exponer claves ni depender de Internet.
   *
   * MODO IA:
   * Cuando se configure un proveedor, esta función será el único punto
   * que necesita cambiar para realizar la llamada real.
   */
  if (!process.env.AI_API_URL || !process.env.AI_API_KEY) {
    return demoPlan(input);
  }

  const prompt = buildPrompt(input);

  // Adaptador genérico para proveedores compatibles con una API HTTP de chat.
  const response = await fetch(process.env.AI_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${process.env.AI_API_KEY}`
    },
    body: JSON.stringify({
      model: process.env.AI_MODEL || "configured-model",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: prompt }
      ],
      temperature: 0.4
    })
  });

  if (!response.ok) {
    throw new Error(`AI provider returned ${response.status}`);
  }

  const data = await response.json();

  // Se espera una respuesta con choices[0].message.content.
  const content = data?.choices?.[0]?.message?.content;
  if (!content) throw new Error("La respuesta del proveedor no contiene contenido.");

  return parseJson(content);
}

function parseJson(content) {
  const cleaned = content
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();

  try {
    return JSON.parse(cleaned);
  } catch {
    throw new Error("El modelo no devolvió JSON válido.");
  }
}

function demoPlan(input) {
  const topic = input.topic || "Operaciones con números enteros";
  return {
    objetivo: input.objective || `Resolver situaciones relacionadas con ${topic}, explicando el procedimiento utilizado.`,
    anticipacion: "Presentar una situación cotidiana relacionada con el tema. Activar conocimientos previos mediante preguntas y una representación visual.",
    construccion: "Construir el procedimiento mediante ejemplos guiados, representación gráfica y práctica progresiva. El docente acompaña y retroalimenta.",
    consolidacion: "Resolver problemas contextualizados de manera individual y colaborativa. Los estudiantes explican y comparan sus procedimientos.",
    recursos: [
      "Recta numérica o representación visual",
      "Ficha de ejercicios",
      "Problemas contextualizados",
      "Actividad colaborativa"
    ],
    evaluacion: [
      "Representa correctamente los conceptos trabajados.",
      "Aplica procedimientos adecuados.",
      "Resuelve situaciones contextualizadas.",
      "Explica el procedimiento utilizado."
    ],
    criterios: [
      "Comprende el concepto.",
      "Aplica el procedimiento.",
      "Argumenta sus respuestas."
    ],
    rubrica: [
      { criterio: "Comprensión", inicial: "Requiere apoyo", proceso: "Comprende parcialmente", logrado: "Comprende y explica" },
      { criterio: "Procedimiento", inicial: "Presenta dificultades", proceso: "Aplica con apoyo", logrado: "Aplica correctamente" },
      { criterio: "Argumentación", inicial: "No justifica", proceso: "Justifica parcialmente", logrado: "Justifica con claridad" }
    ],
    dua: [
      "Representación: utilizar ejemplos visuales y explicaciones paso a paso.",
      "Acción y expresión: permitir respuestas escritas, gráficas u orales.",
      "Participación: combinar trabajo individual y colaborativo."
    ],
    modo: "demo"
  };
}

module.exports = { generateEducationalPlan };
