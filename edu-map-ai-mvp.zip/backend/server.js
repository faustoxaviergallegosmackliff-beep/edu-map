const express = require("express");
const cors = require("cors");
const path = require("path");
const { generateEducationalPlan } = require("./services/ai");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: "100kb" }));

// Servir el frontend desde la carpeta raíz del proyecto.
app.use(express.static(path.join(__dirname, "..")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "EDU-MAP API" });
});

app.post("/api/generate", async (req, res) => {
  try {
    const input = req.body;

    if (!input?.level || !input?.subject || !input?.topic) {
      return res.status(400).json({
        error: "Faltan datos obligatorios: level, subject y topic."
      });
    }

    const result = await generateEducationalPlan(input);
    res.json(result);
  } catch (error) {
    console.error("Generation error:", error.message);
    res.status(500).json({
      error: "No fue posible generar la planificación.",
      detail: process.env.NODE_ENV === "development" ? error.message : undefined
    });
  }
});

app.listen(PORT, () => {
  console.log(`EDU-MAP disponible en http://localhost:${PORT}`);
});
